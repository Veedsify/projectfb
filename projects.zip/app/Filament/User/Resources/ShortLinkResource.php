<?php

namespace App\Filament\User\Resources;

use App\Filament\User\Resources\ShortLinkResource\Pages;
use App\Filament\User\Resources\ShortLinkResource\RelationManagers;
use App\Models\ShortLink;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class ShortLinkResource extends Resource
{
    protected static ?string $model = ShortLink::class;

    protected static ?string $navigationIcon = "heroicon-o-link";

    public static function form(Form $form): Form
    {
        return $form->schema([
            //
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make("code")
                    ->label("Link ID")
                    ->searchable()
                    ->sortable(),
                TextColumn::make("user.name")
                    ->label("Owner")
                    ->searchable()
                    ->sortable(),
                TextColumn::make("filled")
                    ->label("Has Been Filled")
                    ->getStateUsing(function ($record) {
                        return $record->filled ? "Yes" : "No";
                    })
                    ->badge()
                    ->color(
                        fn($record) => $record->filled ? "success" : "danger"
                    )
                    ->searchable()
                    ->sortable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make("copy link")
                    ->color("info")
                    ->slideOver()
                    ->modalSubmitAction(false)
                    ->modalContent(function ($record) {
                        return view("livewire.components.copy", [
                            "record" => $record,
                        ]);
                    }),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
                //
            ];
    }

    public static function getPages(): array
    {
        return [
            "index" => Pages\ListShortLinks::route("/"),
            "create" => Pages\CreateShortLink::route("/create"),
            "edit" => Pages\EditShortLink::route("/{record}/edit"),
        ];
    }
}
