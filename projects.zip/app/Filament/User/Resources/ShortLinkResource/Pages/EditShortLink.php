<?php

namespace App\Filament\User\Resources\ShortLinkResource\Pages;

use App\Filament\User\Resources\ShortLinkResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditShortLink extends EditRecord
{
    protected static string $resource = ShortLinkResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
