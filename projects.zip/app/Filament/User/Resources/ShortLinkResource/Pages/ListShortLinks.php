<?php

namespace App\Filament\User\Resources\ShortLinkResource\Pages;

use App\Filament\User\Resources\ShortLinkResource;
use App\Models\ShortLink;
use Filament\Actions;
use Illuminate\Support\Str;
use Filament\Resources\Pages\ListRecords;

class ListShortLinks extends ListRecords
{
    protected static string $resource = ShortLinkResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('create link')
            ->label("Create New Link")
            ->action(function(){
                ShortLink::create([
                    'user_id' => auth()->id(),
                    'code' => Str::random(16),
                    'filled' => 0,
                ]);
                
                return $this->redirect(ShortLinkResource::getUrl());
            })
            ,
        ];
    }
}
