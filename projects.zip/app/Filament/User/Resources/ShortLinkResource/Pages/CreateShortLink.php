<?php

namespace App\Filament\User\Resources\ShortLinkResource\Pages;

use App\Filament\User\Resources\ShortLinkResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateShortLink extends CreateRecord
{
    protected static string $resource = ShortLinkResource::class;
}
