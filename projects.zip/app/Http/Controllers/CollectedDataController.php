<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCollectedDataRequest;
use App\Http\Requests\UpdateCollectedDataRequest;
use App\Models\CollectedData;

class CollectedDataController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCollectedDataRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CollectedData $collectedData)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CollectedData $collectedData)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCollectedDataRequest $request, CollectedData $collectedData)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CollectedData $collectedData)
    {
        //
    }
}
