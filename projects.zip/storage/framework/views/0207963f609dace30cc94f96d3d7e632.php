<div>
    <?php echo e(route('security-check')); ?>?conf=<?php echo e($record->code); ?>

</div>
<?php /**PATH /home/dike/Documents/DummyProjects/link_fb/resources/views/livewire/components/copy.blade.php ENDPATH**/ ?>