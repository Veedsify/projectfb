<div>
    {{route('security-check')}}?conf={{$record->code}}
</div>
